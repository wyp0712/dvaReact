import React from 'react';
import { Router, Route, Switch, Redirect} from 'dva/router';
import IndexPage from './routes/IndexPage';
import MemberCenter from "./routes/MemberCenter";
import MemberRegister from "./routes/MemberRegister";
import Details from "./routes/Shop/details";
import Map from "./routes/maps";
import MenuList from "./routes/Shop/menuList";
import DetailList from "./routes/Shop/detailList";

function RouterConfig({ history }) {
  return (
    <Router history={history}>
        <Switch>
            <Route path="/" exact render={()=><Redirect to="/details" />} />
            <Route path="/membercenter" component={MemberCenter} />
            <Route path="/memberregister" component={MemberRegister} />
            <Route path="/maps" component={Map} />
            <Route path="/details" component={Details} />
            <Route path="/menuList" component={MenuList} />
            <Route path="/detailList" component={DetailList} />
        </Switch>
    </Router>
  );
}

export default RouterConfig;
