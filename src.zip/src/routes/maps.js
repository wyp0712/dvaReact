import React from 'react';
import { connect } from 'dva';
import styles from './IndexPage.css';

function Map() {
  return (
    <div className={styles.normal}>
        this is 啊  maps
    </div>
  );
}

Map.propTypes = {
};

export default connect()(Map);
