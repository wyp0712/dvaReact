import axios from "axios";
import MockAdapter from "axios-mock-adapter";
import data from "./data.json"

let mock = new MockAdapter(axios)

mock.onGet("/api").reply(200,data)