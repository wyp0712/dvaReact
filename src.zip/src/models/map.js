
export default {
  namespace: 'map',
  state: {},
  subscriptions: {},
  effects: {},
  reducers: {
    setup(){
      console.log("this is a map")
    }
  }
};
