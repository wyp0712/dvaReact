import axios from "axios";
export default {
  namespace: 'Lists',
  state: {
  },
  subscriptions: {},
  effects: {
    *fetchData({},{call,put}){
        const json = yield axios("/api").then((res)=>res.data).catch((err)=>{
          return {
            code:0
          }
        })
        if(!json.code){
           yield put({type:"save",payLoad:json})
           return Promise.resolve(1);
        }else{
           return Promise.reject(0);
        }
    }
  },
  reducers: {
    save(state,action){
      return {
        ...state,
        ...action.payLoad
      }
    },
    addCar(){
      
    }
  }
};
