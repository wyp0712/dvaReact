
export default {
  namespace: 'details',
  state: {},
  reducers: {},
  effects: {},
  subscriptions: {
    setup(){
      console.log("这是    details")
    }
  },
};
