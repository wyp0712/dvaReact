
export default {
  namespace: 'memberCenter',
  state: {},
  reducers: {},
  effects: {},
  subscriptions: {
    setup(){
      console.log("这是memberCenter")
    }
  },
};
