import React from 'react';

const Map = () => {
  return (
    <div>
      Map
    </div>
  );
};

Map.propTypes = {
};

export default Map;
