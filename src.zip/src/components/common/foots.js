import React from 'react';
import { connect } from 'dva';
import styles from './foots.css';
import { Icon } from 'antd'

class Footer extends React.Component {
    constructor() {
        super()
    }
    render() {
        return (
            <footer className={styles.footers}>
                <p>
                     <Icon type="shopping-cart" className={styles.icon} />
                </p>
                <span className={styles.one}>￥46</span>
                <span className={styles.two}>选好了</span>
            </footer>
        )
    }
}

function mapStateToProps() {
    return {};
}

export default connect(mapStateToProps)(Footer);
