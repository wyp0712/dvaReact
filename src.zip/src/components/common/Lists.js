import React from 'react';
import { connect } from 'dva';
import styles from "./Lists.css"
import { withRouter } from 'dva/router';

class DetailList extends React.Component {
    constructor(props) {
        super(props)
        this.add = this.add.bind(this)
    }
    jumpRoute(items){
        window.sessionStorage.setItem('data',JSON.stringify(items));
        this.props.history.push({
            pathname: '/detailList', query: {
                items,
            }
        })
    }
    add(e){
        e.stopPropagation();
        e.target.style.display = "none";
        this.refs.num.style.display = "block";
    }
    render() {
        let items = this.props.items;
        return (  
            <li className={styles.fooditem} onClick={
                    ()=>{
                        this.jumpRoute(items)
                    }
                }>
                <div className={styles.icon}>
                    <img src={items.image} />
                </div>
                <div className={styles.content}>
                    <h2 className={styles.name}>{items.name}</h2>
                    <p className={styles.desc}>{items.description}</p>
                    <div className={styles.price}>
                        <span className={styles.now}>￥{items.price}</span>
                        <span className={styles.old}>￥{items.oldPrice}</span>
                    </div>
                    <p className={styles.num} ref="num">
                        <span
                            className={styles.mixin}
                            onClick={
                                (e)=>{
                                    e.stopPropagation();
                                    if(this.refs.dom.innerHTML>0){
                                        this.refs.dom.innerHTML--
                                    }else{
                                        this.refs.dom.innerHTML=0
                                    }
                                }
                            }
                        >-</span>
                        <span
                            className={styles.count}
                            ref="dom"
                        >{items.sellCount}</span>
                        <span
                            className={styles.add}
                            onClick={
                                (e)=>{
                                    e.stopPropagation();
                                    this.refs.dom.innerHTML++;
                                }
                            }
                        >+</span>
                    </p>
                    <p className={styles.specificat}
                        onClick={
                            (e)=>{
                                this.add(e)
                            }
                        }
                    >选规格</p>
                </div>
            </li>
        )
    }
}


DetailList.propTypes = {
};

export default withRouter(DetailList)
