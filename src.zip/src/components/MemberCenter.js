import React from 'react';
import styles from './MemberCenter.css';

function MemberCenter() {
  return (
    <div className={styles.normal}>
      Component: MemberCenter
    </div>
  );
}

export default MemberCenter;
