import React from 'react';
import styles from './MemberRegister.css';

function MemberRegister() {
  return (
    <div className={styles.normal}>
      Component: MemberRegister
    </div>
  );
}

export default MemberRegister;
