import React from 'react';

const MenuList = () => {
  return (
    <div>
      MenuList
    </div>
  );
};

MenuList.propTypes = {
};

export default MenuList;
