import React from 'react';
import styles from './details.css';

function Details() {
  return (
    <div className={styles.normal}>
      Component: Details
    </div>
  );
}

export default Details;
